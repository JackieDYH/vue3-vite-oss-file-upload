import { PureComponent } from 'react';


export default class GlobalHeaderRight extends PureComponent {
  render() {
    return null;
  }
}
