import DescriptionList from './DescriptionList';
import Description from './Description';

DescriptionList.Description = Description;
export default DescriptionList;
